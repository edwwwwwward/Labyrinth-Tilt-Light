package com.example.myapplication.data

import kotlinx.coroutines.flow.Flow

interface GameRecordDao {
    suspend fun insertRecord(record: GameRecord)
    fun getAllRecords(): Flow<List<GameRecord>>
}
