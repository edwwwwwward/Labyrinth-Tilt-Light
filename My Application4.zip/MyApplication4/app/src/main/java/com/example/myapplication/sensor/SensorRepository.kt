package com.example.myapplication.sensor

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

data class TiltData(val tiltX: Float, val tiltY: Float)

class SensorRepository(context: Context) {
    private val sensorManager =
        context.applicationContext.getSystemService(Context.SENSOR_SERVICE) as? SensorManager

    fun getAccelerometerFlow(): Flow<TiltData> = callbackFlow {
        val accelSensor = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        if (sensorManager == null || accelSensor == null) {
            trySend(TiltData(0f, 0f))
            awaitClose { }
            return@callbackFlow
        }

        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent?) {
                event?.let {
                    if (it.sensor.type == Sensor.TYPE_ACCELEROMETER) {
                        // Sumbu X: Kemiringan kiri/kanan (-ax), Sumbu Y: Kemiringan maju/mundur (ay)
                        val tiltX = -it.values[0]
                        val tiltY = it.values[1]
                        trySend(TiltData(tiltX, tiltY))
                    }
                }
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }

        val registered = sensorManager.registerListener(
            listener,
            accelSensor,
            SensorManager.SENSOR_DELAY_GAME
        )

        if (!registered) {
            trySend(TiltData(0f, 0f))
        }

        awaitClose {
            sensorManager.unregisterListener(listener)
        }
    }

    fun getLightFlow(): Flow<Float> = callbackFlow {
        val lightSensor = sensorManager?.getDefaultSensor(Sensor.TYPE_LIGHT)
        if (sensorManager == null || lightSensor == null) {
            trySend(100f) // Default lux terang jika tidak ada sensor cahaya
            awaitClose { }
            return@callbackFlow
        }

        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent?) {
                event?.let {
                    if (it.sensor.type == Sensor.TYPE_LIGHT) {
                        val lux = it.values[0]
                        trySend(lux)
                    }
                }
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }

        val registered = sensorManager.registerListener(
            listener,
            lightSensor,
            SensorManager.SENSOR_DELAY_UI
        )

        if (!registered) {
            trySend(100f)
        }

        awaitClose {
            sensorManager.unregisterListener(listener)
        }
    }
}
