package com.example.myapplication.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.myapplication.data.GameRecord
import com.example.myapplication.data.GameRepository
import com.example.myapplication.data.MazeMap
import com.example.myapplication.sensor.SensorRepository
import com.example.myapplication.sensor.TiltData
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

enum class GameStatus {
    IDLE,       // Di Menu
    PLAYING,    // Dalam Game
    WON,        // Menang / Garis Finis
    GAME_OVER   // Jatuh ke Lubang
}

data class GameUiState(
    val status: GameStatus = GameStatus.IDLE,
    val elapsedSeconds: Long = 0L,
    val lux: Float = 100f,
    val isDark: Boolean = false,
    val ballX: Float = 0.5f,
    val ballY: Float = 0.5f,
    val ballVx: Float = 0f,
    val ballVy: Float = 0f,
    val maze: MazeMap = MazeMap(),
    val isSimulationActive: Boolean = false,
    val simulatedTiltX: Float = 0f,
    val simulatedTiltY: Float = 0f,
    val simulatedLux: Float = 100f
)

class GameViewModel(
    private val gameRepository: GameRepository,
    private val sensorRepository: SensorRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(GameUiState())
    val uiState: StateFlow<GameUiState> = _uiState.asStateFlow()

    val leaderboard: StateFlow<List<GameRecord>> = gameRepository.allRecords.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    private var currentTiltX: Float = 0f
    private var currentTiltY: Float = 0f
    private var gameLoopJob: Job? = null
    private var timerJob: Job? = null

    init {
        observeSensors()
    }

    private fun observeSensors() {
        // Accelerometer
        viewModelScope.launch {
            sensorRepository.getAccelerometerFlow().collectLatest { tilt ->
                currentTiltX = tilt.tiltX
                currentTiltY = tilt.tiltY
            }
        }

        // Light Sensor
        viewModelScope.launch {
            sensorRepository.getLightFlow().collectLatest { luxVal ->
                _uiState.update { state ->
                    val activeLux = if (state.isSimulationActive) state.simulatedLux else luxVal
                    state.copy(
                        lux = activeLux,
                        isDark = activeLux <= 50.0f
                    )
                }
            }
        }
    }

    fun startGame() {
        val maze = _uiState.value.maze
        val startX = maze.startCell.col + 0.5f
        val startY = maze.startCell.row + 0.5f

        _uiState.update {
            it.copy(
                status = GameStatus.PLAYING,
                elapsedSeconds = 0L,
                ballX = startX,
                ballY = startY,
                ballVx = 0f,
                ballVy = 0f
            )
        }

        startTimer()
        startGameLoop()
    }

    fun restartGame() {
        startGame()
    }

    fun backToMenu() {
        gameLoopJob?.cancel()
        timerJob?.cancel()
        _uiState.update { it.copy(status = GameStatus.IDLE) }
    }

    fun setSimulationActive(active: Boolean) {
        _uiState.update { state ->
            val newLux = if (active) state.simulatedLux else state.lux
            state.copy(
                isSimulationActive = active,
                lux = newLux,
                isDark = newLux <= 50.0f
            )
        }
    }

    fun updateSimulatedTilt(tiltX: Float, tiltY: Float) {
        _uiState.update {
            it.copy(
                simulatedTiltX = tiltX,
                simulatedTiltY = tiltY
            )
        }
    }

    fun updateSimulatedLux(lux: Float) {
        _uiState.update { state ->
            val activeLux = if (state.isSimulationActive) lux else state.lux
            state.copy(
                simulatedLux = lux,
                lux = activeLux,
                isDark = activeLux <= 50.0f
            )
        }
    }

    private fun startTimer() {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (_uiState.value.status == GameStatus.PLAYING) {
                delay(1000L)
                _uiState.update { it.copy(elapsedSeconds = it.elapsedSeconds + 1) }
            }
        }
    }

    private fun startGameLoop() {
        gameLoopJob?.cancel()
        gameLoopJob = viewModelScope.launch {
            val ballRadius = 0.35f

            while (_uiState.value.status == GameStatus.PLAYING) {
                val state = _uiState.value
                val tiltX = if (state.isSimulationActive) state.simulatedTiltX else currentTiltX
                val tiltY = if (state.isSimulationActive) state.simulatedTiltY else currentTiltY

                // Akselerasi & Gesekan (Fisika)
                val ax = tiltX * 0.08f
                val ay = tiltY * 0.08f

                var vx = (state.ballVx + ax) * 0.88f
                var vy = (state.ballVy + ay) * 0.88f

                var nx = state.ballX + vx * 0.1f
                var ny = state.ballY + vy * 0.1f

                val maze = state.maze

                // Pembatasan Batas Luar Grid (Outer Bounds Collision)
                if (nx - ballRadius < 0f) {
                    nx = ballRadius
                    vx = 0f
                } else if (nx + ballRadius > maze.cols) {
                    nx = maze.cols - ballRadius
                    vx = 0f
                }

                if (ny - ballRadius < 0f) {
                    ny = ballRadius
                    vy = 0f
                } else if (ny + ballRadius > maze.rows) {
                    ny = maze.rows - ballRadius
                    vy = 0f
                }

                // Tabrakan Dinding Dalam Labirin (Inner Walls Collision)
                for (wall in maze.innerWalls) {
                    val collisionResult = resolveWallCollision(
                        px = nx, py = ny,
                        radius = ballRadius,
                        x1 = wall.startCol, y1 = wall.startRow,
                        x2 = wall.endCol, y2 = wall.endRow
                    )

                    if (collisionResult != null) {
                        nx = collisionResult.first
                        ny = collisionResult.second
                        vx *= 0.5f
                        vy *= 0.5f
                    }
                }

                // Deteksi Lubang Jebakan (Trap Holes)
                var fallenInHole = false
                for (hole in maze.trapHoles) {
                    val holeCenterX = hole.col + 0.5f
                    val holeCenterY = hole.row + 0.5f
                    val dx = nx - holeCenterX
                    val dy = ny - holeCenterY
                    val dist = sqrt(dx * dx + dy * dy)

                    if (dist < 0.35f) { // Lingkaran bola masuk ke dalam area lubang
                        fallenInHole = true
                        break
                    }
                }

                if (fallenInHole) {
                    _uiState.update {
                        it.copy(
                            status = GameStatus.GAME_OVER,
                            ballX = nx,
                            ballY = ny,
                            ballVx = 0f,
                            ballVy = 0f
                        )
                    }
                    timerJob?.cancel()
                    break
                }

                // Deteksi Garis Finis
                val finishCenterX = maze.finishCell.col + 0.5f
                val finishCenterY = maze.finishCell.row + 0.5f
                val fdx = nx - finishCenterX
                val fdy = ny - finishCenterY
                val finishDist = sqrt(fdx * fdx + fdy * fdy)

                if (finishDist < 0.45f) {
                    val finalSeconds = state.elapsedSeconds
                    val lightModeText = if (state.isDark) "Mode Gelap" else "Mode Terang"

                    _uiState.update {
                        it.copy(
                            status = GameStatus.WON,
                            ballX = nx,
                            ballY = ny,
                            ballVx = 0f,
                            ballVy = 0f
                        )
                    }

                    timerJob?.cancel()

                    // Simpan Rekor ke Room SQLite
                    viewModelScope.launch {
                        gameRepository.saveRecord(
                            GameRecord(
                                levelName = "Labirin Utama",
                                completionTimeSeconds = max(1L, finalSeconds),
                                lightCondition = lightModeText
                            )
                        )
                    }
                    break
                }

                _uiState.update {
                    it.copy(
                        ballX = nx,
                        ballY = ny,
                        ballVx = vx,
                        ballVy = vy
                    )
                }

                delay(16L) // ~60 FPS
            }
        }
    }

    private fun resolveWallCollision(
        px: Float, py: Float, radius: Float,
        x1: Float, y1: Float, x2: Float, y2: Float
    ): Pair<Float, Float>? {
        val dx = x2 - x1
        val dy = y2 - y1
        val lenSq = dx * dx + dy * dy
        if (lenSq == 0f) return null

        val t = max(0f, min(1f, ((px - x1) * dx + (py - y1) * dy) / lenSq))
        val projX = x1 + t * dx
        val projY = y1 + t * dy

        val distX = px - projX
        val distY = py - projY
        val dist = sqrt(distX * distX + distY * distY)

        if (dist < radius && dist > 0.0001f) {
            val overlap = radius - dist
            val normX = distX / dist
            val normY = distY / dist
            return Pair(px + normX * overlap, py + normY * overlap)
        }
        return null
    }

    class Factory(
        private val gameRepository: GameRepository,
        private val sensorRepository: SensorRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return GameViewModel(gameRepository, sensorRepository) as T
        }
    }
}
