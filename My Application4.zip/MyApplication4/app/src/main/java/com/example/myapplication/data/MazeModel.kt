package com.example.myapplication.data

data class CellPos(val col: Int, val row: Int)

data class WallSegment(
    val startCol: Float,
    val startRow: Float,
    val endCol: Float,
    val endRow: Float
)

data class TrapHole(val col: Int, val row: Int)

data class MazeMap(
    val cols: Int = 10,
    val rows: Int = 14,
    val startCell: CellPos = CellPos(0, 0),
    val finishCell: CellPos = CellPos(9, 13),
    val trapHoles: List<TrapHole> = listOf(
        TrapHole(4, 6),
        TrapHole(2, 10)
    ),
    val innerWalls: List<WallSegment> = listOf(
        // Dinding pemandu pendek yang tidak menutup seluruh jalur (Dijamin ada jalan terbuka luas menuju finish)
        WallSegment(0f, 4f, 6f, 4f),  // Menyisakan kolom 7, 8, 9 terbuka di sisi kanan
        WallSegment(3f, 9f, 10f, 9f), // Menyisakan kolom 0, 1, 2 terbuka di sisi kiri
        WallSegment(3f, 1f, 3f, 3f),  // Dinding pemandu atas
        WallSegment(7f, 11f, 7f, 13f) // Dinding pemandu bawah mendekati titik finish
    )
)
