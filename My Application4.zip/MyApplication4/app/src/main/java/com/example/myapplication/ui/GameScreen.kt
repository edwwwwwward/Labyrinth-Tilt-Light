package com.example.myapplication.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.NightlightRound
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SentimentVeryDissatisfied
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.myapplication.data.MazeMap
import com.example.myapplication.viewmodel.GameStatus
import com.example.myapplication.viewmodel.GameUiState

@Composable
fun GameScreen(
    uiState: GameUiState,
    onRestart: () -> Unit,
    onBackToMenu: () -> Unit,
    onSetSimulationActive: (Boolean) -> Unit,
    onUpdateSimulatedTilt: (Float, Float) -> Unit,
    onUpdateSimulatedLux: (Float) -> Unit
) {
    var showSimulationPanel by remember { mutableStateOf(false) }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp)
        ) {
            // HUD Top Bar
            GameHudTopBar(
                elapsedSeconds = uiState.elapsedSeconds,
                lux = uiState.lux,
                isDark = uiState.isDark,
                isSimulationActive = uiState.isSimulationActive,
                onToggleSimulationPanel = { showSimulationPanel = !showSimulationPanel },
                onRestart = onRestart,
                onBackToMenu = onBackToMenu
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Canvas Papan Labirin 2D
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF1E293B)),
                contentAlignment = Alignment.Center
            ) {
                MazeCanvas(
                    uiState = uiState,
                    modifier = Modifier.fillMaxSize()
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Panel Simulasi Sensor (Untuk Testing di Emulator)
            AnimatedVisibility(visible = showSimulationPanel) {
                SimulationControlPanel(
                    isSimulationActive = uiState.isSimulationActive,
                    simulatedTiltX = uiState.simulatedTiltX,
                    simulatedTiltY = uiState.simulatedTiltY,
                    simulatedLux = uiState.simulatedLux,
                    onSetSimulationActive = onSetSimulationActive,
                    onUpdateSimulatedTilt = onUpdateSimulatedTilt,
                    onUpdateSimulatedLux = onUpdateSimulatedLux
                )
            }
        }
    }

    // Dialog Menang (Victory)
    if (uiState.status == GameStatus.WON) {
        VictoryDialog(
            elapsedSeconds = uiState.elapsedSeconds,
            lightCondition = if (uiState.isDark) "Mode Gelap (<=50 Lux)" else "Mode Terang (>50 Lux)",
            onRestart = onRestart,
            onBackToMenu = onBackToMenu
        )
    }

    // Dialog Game Over (Lubang Jebakan)
    if (uiState.status == GameStatus.GAME_OVER) {
        GameOverDialog(
            onRestart = onRestart,
            onBackToMenu = onBackToMenu
        )
    }
}

@Composable
private fun GameHudTopBar(
    elapsedSeconds: Long,
    lux: Float,
    isDark: Boolean,
    isSimulationActive: Boolean,
    onToggleSimulationPanel: () -> Unit,
    onRestart: () -> Unit,
    onBackToMenu: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Tombol Kembali
            IconButton(onClick = onBackToMenu) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Kembali ke Menu"
                )
            }

            // Timer
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(MaterialTheme.colorScheme.primaryContainer)
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Timer,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                val minutes = elapsedSeconds / 60
                val seconds = elapsedSeconds % 60
                Text(
                    text = String.format(java.util.Locale.getDefault(), "%02d:%02d", minutes, seconds),
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            // Status Sensor Cahaya
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (isDark) Color(0xFF334155) else Color(0xFFFEF3C7))
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Icon(
                    imageVector = if (isDark) Icons.Default.NightlightRound else Icons.Default.LightMode,
                    contentDescription = null,
                    tint = if (isDark) Color(0xFFF59E0B) else Color(0xFFD97706),
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "${lux.toInt()} Lux",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = if (isDark) Color.White else Color(0xFF92400E)
                )
            }

            // Tombol Control Emulator
            IconButton(onClick = onToggleSimulationPanel) {
                Icon(
                    imageVector = Icons.Default.Smartphone,
                    contentDescription = "Simulasi Sensor",
                    tint = if (isSimulationActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Tombol Reset
            IconButton(onClick = onRestart) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Reset Level"
                )
            }
        }
    }
}

@Composable
private fun MazeCanvas(
    uiState: GameUiState,
    modifier: Modifier = Modifier
) {
    val maze = uiState.maze
    val ballX = uiState.ballX
    val ballY = uiState.ballY
    val isDark = uiState.isDark

    Canvas(modifier = modifier) {
        val cellWidth = size.width / maze.cols
        val cellHeight = size.height / maze.rows

        // 1. Gambar Titik Start (Biru)
        val startX = maze.startCell.col * cellWidth
        val startY = maze.startCell.row * cellHeight
        drawRect(
            color = Color(0xFF3B82F6).copy(alpha = 0.35f),
            topLeft = Offset(startX, startY),
            size = Size(cellWidth, cellHeight)
        )

        // 2. Gambar Titik Finis (Hijau)
        val finishX = maze.finishCell.col * cellWidth
        val finishY = maze.finishCell.row * cellHeight
        drawRect(
            color = Color(0xFF10B981).copy(alpha = 0.45f),
            topLeft = Offset(finishX, finishY),
            size = Size(cellWidth, cellHeight)
        )
        // Ikon Bintang/Finis sederhana
        drawCircle(
            color = Color(0xFF10B981),
            radius = minOf(cellWidth, cellHeight) * 0.25f,
            center = Offset(finishX + cellWidth / 2f, finishY + cellHeight / 2f)
        )

        // 3. Gambar Lubang Jebakan (Trap Holes)
        val holeRadius = minOf(cellWidth, cellHeight) * 0.35f
        for (hole in maze.trapHoles) {
            val hx = (hole.col + 0.5f) * cellWidth
            val hy = (hole.row + 0.5f) * cellHeight

            // Lingkaran luar hitam & ring merah
            drawCircle(
                color = Color(0xFFEF4444),
                radius = holeRadius,
                center = Offset(hx, hy),
                style = Stroke(width = 3f)
            )
            drawCircle(
                color = Color(0xFF0F172A),
                radius = holeRadius * 0.85f,
                center = Offset(hx, hy)
            )
        }

        // 4. Gambar Dinding Dalam Labirin (Inner Walls)
        val wallStroke = 6.dp.toPx()
        val wallColor = Color(0xFF64748B)

        for (wall in maze.innerWalls) {
            val x1 = wall.startCol * cellWidth
            val y1 = wall.startRow * cellHeight
            val x2 = wall.endCol * cellWidth
            val y2 = wall.endRow * cellHeight

            drawLine(
                color = wallColor,
                start = Offset(x1, y1),
                end = Offset(x2, y2),
                strokeWidth = wallStroke,
                cap = StrokeCap.Round
            )
        }

        // Dinding Luar Grid
        drawRect(
            color = wallColor,
            topLeft = Offset(0f, 0f),
            size = Size(size.width, size.height),
            style = Stroke(width = wallStroke * 1.5f)
        )

        // 5. Gambar Bola Pemain (Player Ball)
        val ballCanvasX = ballX * cellWidth
        val ballCanvasY = ballY * cellHeight
        val ballRadiusPx = minOf(cellWidth, cellHeight) * 0.35f

        // Bayangan Bola
        drawCircle(
            color = Color.Black.copy(alpha = 0.3f),
            radius = ballRadiusPx,
            center = Offset(ballCanvasX + 3f, ballCanvasY + 3f)
        )

        // Gradient Bola Cyan/Blue
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0xFF38BDF8), Color(0xFF0284C7)),
                center = Offset(ballCanvasX - ballRadiusPx * 0.2f, ballCanvasY - ballRadiusPx * 0.2f),
                radius = ballRadiusPx * 1.2f
            ),
            radius = ballRadiusPx,
            center = Offset(ballCanvasX, ballCanvasY)
        )

        // 6. Efek Senter / Fog of War jika Ruangan Gelap (<= 50 Lux)
        if (isDark) {
            val spotlightRadius = minOf(size.width, size.height) * 0.38f

            // Menggambar Radial Gradient Spotlight di sekitar posisi bola
            drawRect(
                brush = Brush.radialGradient(
                    colorStops = arrayOf(
                        0.0f to Color.Transparent,
                        0.45f to Color.Transparent,
                        0.75f to Color.Black.copy(alpha = 0.75f),
                        1.0f to Color.Black
                    ),
                    center = Offset(ballCanvasX, ballCanvasY),
                    radius = spotlightRadius
                ),
                topLeft = Offset(0f, 0f),
                size = size
            )
        }
    }
}

@Composable
private fun SimulationControlPanel(
    isSimulationActive: Boolean,
    simulatedTiltX: Float,
    simulatedTiltY: Float,
    simulatedLux: Float,
    onSetSimulationActive: (Boolean) -> Unit,
    onUpdateSimulatedTilt: (Float, Float) -> Unit,
    onUpdateSimulatedLux: (Float) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Mode Simulasi Sensor (Emulator)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Switch(
                    checked = isSimulationActive,
                    onCheckedChange = onSetSimulationActive
                )
            }

            if (isSimulationActive) {
                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Touch Joystick / Pad untuk Kemiringan (Tilt)
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = "Kemiringan (Touch Pad)",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Box(
                            modifier = Modifier
                                .size(110.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.background)
                                .pointerInput(Unit) {
                                    detectDragGestures(
                                        onDragEnd = { onUpdateSimulatedTilt(0f, 0f) },
                                        onDragCancel = { onUpdateSimulatedTilt(0f, 0f) }
                                    ) { change, dragAmount ->
                                        change.consume()
                                        val maxRange = 50f
                                        val newX = (dragAmount.x / maxRange).coerceIn(-10f, 10f)
                                        val newY = (dragAmount.y / maxRange).coerceIn(-10f, 10f)
                                        onUpdateSimulatedTilt(
                                            (simulatedTiltX + newX).coerceIn(-10f, 10f),
                                            (simulatedTiltY + newY).coerceIn(-10f, 10f)
                                        )
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Geser Bola",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                            )
                            // Thumb Indicator
                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primary)
                            )
                        }
                        Text(
                            text = String.format(java.util.Locale.getDefault(), "X: %.1f | Y: %.1f", simulatedTiltX, simulatedTiltY),
                            style = MaterialTheme.typography.labelSmall
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    // Slider Intensitas Cahaya (Lux)
                    Column(modifier = Modifier.weight(1.2f)) {
                        Text(
                            text = "Simulasi Cahaya Lux: ${simulatedLux.toInt()} Lux",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Slider(
                            value = simulatedLux,
                            onValueChange = onUpdateSimulatedLux,
                            valueRange = 0f..200f
                        )
                        Text(
                            text = if (simulatedLux <= 50f) "Mode Gelap (<=50 Lux)" else "Mode Terang (>50 Lux)",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (simulatedLux <= 50f) Color(0xFFF59E0B) else Color(0xFF10B981),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun VictoryDialog(
    elapsedSeconds: Long,
    lightCondition: String,
    onRestart: () -> Unit,
    onBackToMenu: () -> Unit
) {
    AlertDialog(
        onDismissRequest = {},
        icon = {
            Icon(
                imageVector = Icons.Default.EmojiEvents,
                contentDescription = null,
                tint = Color(0xFFFFD700),
                modifier = Modifier.size(48.dp)
            )
        },
        title = {
            Text(
                text = "Menang!",
                fontWeight = FontWeight.Bold,
                fontSize = 22.sp
            )
        },
        text = {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "Selamat! Anda berhasil mencapai garis finis.",
                    fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(12.dp))
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Waktu Penyelesaian: $elapsedSeconds detik",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "Kondisi Cahaya: $lightCondition",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = onRestart) {
                Text("Main Lagi")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onBackToMenu) {
                Text("Kembali ke Menu")
            }
        }
    )
}

@Composable
private fun GameOverDialog(
    onRestart: () -> Unit,
    onBackToMenu: () -> Unit
) {
    AlertDialog(
        onDismissRequest = {},
        icon = {
            Icon(
                imageVector = Icons.Default.SentimentVeryDissatisfied,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.error,
                modifier = Modifier.size(48.dp)
            )
        },
        title = {
            Text(
                text = "Game Over!",
                fontWeight = FontWeight.Bold,
                fontSize = 22.sp,
                color = MaterialTheme.colorScheme.error
            )
        },
        text = {
            Text(
                text = "Bola terjatuh ke dalam lubang jebakan! Coba lagi dan berhati-hatilah saat memiringkan perangkat.",
                fontSize = 15.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        },
        confirmButton = {
            Button(
                onClick = onRestart,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.error
                )
            ) {
                Text("Coba Lagi")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onBackToMenu) {
                Text("Kembali ke Menu")
            }
        }
    )
}
