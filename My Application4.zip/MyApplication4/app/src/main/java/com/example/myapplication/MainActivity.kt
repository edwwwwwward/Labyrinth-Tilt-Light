package com.example.myapplication

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.myapplication.data.AppDatabase
import com.example.myapplication.data.GameRepository
import com.example.myapplication.sensor.SensorRepository
import com.example.myapplication.ui.GameScreen
import com.example.myapplication.ui.MainScreen
import com.example.myapplication.ui.theme.MyApplicationTheme
import com.example.myapplication.viewmodel.GameStatus
import com.example.myapplication.viewmodel.GameViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val database = AppDatabase.getInstance(applicationContext)
        val gameRepository = GameRepository(database.gameRecordDao())
        val sensorRepository = SensorRepository(applicationContext)

        setContent {
            MyApplicationTheme {
                LabyrinthApp(
                    gameRepository = gameRepository,
                    sensorRepository = sensorRepository
                )
            }
        }
    }
}

@Composable
fun LabyrinthApp(
    gameRepository: GameRepository,
    sensorRepository: SensorRepository,
    viewModel: GameViewModel = viewModel(
        factory = GameViewModel.Factory(gameRepository, sensorRepository)
    )
) {
    val uiState by viewModel.uiState.collectAsState()
    val leaderboard by viewModel.leaderboard.collectAsState()

    if (uiState.status == GameStatus.IDLE) {
        MainScreen(
            leaderboard = leaderboard,
            onStartGame = { viewModel.startGame() }
        )
    } else {
        GameScreen(
            uiState = uiState,
            onRestart = { viewModel.restartGame() },
            onBackToMenu = { viewModel.backToMenu() },
            onSetSimulationActive = { active -> viewModel.setSimulationActive(active) },
            onUpdateSimulatedTilt = { tiltX, tiltY -> viewModel.updateSimulatedTilt(tiltX, tiltY) },
            onUpdateSimulatedLux = { lux -> viewModel.updateSimulatedLux(lux) }
        )
    }
}
