package com.example.myapplication.data

data class GameRecord(
    val id: Long = 0,
    val levelName: String,
    val completionTimeSeconds: Long,
    val lightCondition: String, // "Mode Terang" atau "Mode Gelap"
    val timestamp: Long = System.currentTimeMillis()
)
