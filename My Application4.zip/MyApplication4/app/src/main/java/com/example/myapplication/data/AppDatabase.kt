package com.example.myapplication.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AppDatabase private constructor(context: Context) : SQLiteOpenHelper(
    context.applicationContext,
    DATABASE_NAME,
    null,
    DATABASE_VERSION
), GameRecordDao {

    private val updateTrigger = MutableSharedFlow<Unit>(
        replay = 1,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    ).apply { tryEmit(Unit) }

    override fun onCreate(db: SQLiteDatabase) {
        val createTableSql = """
            CREATE TABLE IF NOT EXISTS game_record (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                levelName TEXT NOT NULL,
                completionTimeSeconds INTEGER NOT NULL,
                lightCondition TEXT NOT NULL,
                timestamp INTEGER NOT NULL
            )
        """.trimIndent()
        db.execSQL(createTableSql)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS game_record")
        onCreate(db)
    }

    override suspend fun insertRecord(record: GameRecord): Unit = withContext(Dispatchers.IO) {
        val db = writableDatabase
        val values = ContentValues().apply {
            put("levelName", record.levelName)
            put("completionTimeSeconds", record.completionTimeSeconds)
            put("lightCondition", record.lightCondition)
            put("timestamp", record.timestamp)
        }
        db.insert("game_record", null, values)
        updateTrigger.tryEmit(Unit)
        Unit
    }

    override fun getAllRecords(): Flow<List<GameRecord>> = callbackFlow {
        val job = launch(Dispatchers.IO) {
            updateTrigger.collect {
                val records = queryAllRecordsInternal()
                trySend(records)
            }
        }
        awaitClose { job.cancel() }
    }

    private fun queryAllRecordsInternal(): List<GameRecord> {
        val list = mutableListOf<GameRecord>()
        val db = readableDatabase
        val cursor = db.query(
            "game_record",
            null,
            null,
            null,
            null,
            null,
            "completionTimeSeconds ASC"
        )
        cursor.use { c ->
            val idIdx = c.getColumnIndexOrThrow("id")
            val levelIdx = c.getColumnIndexOrThrow("levelName")
            val timeIdx = c.getColumnIndexOrThrow("completionTimeSeconds")
            val lightIdx = c.getColumnIndexOrThrow("lightCondition")
            val tsIdx = c.getColumnIndexOrThrow("timestamp")

            while (c.moveToNext()) {
                list.add(
                    GameRecord(
                        id = c.getLong(idIdx),
                        levelName = c.getString(levelIdx),
                        completionTimeSeconds = c.getLong(timeIdx),
                        lightCondition = c.getString(lightIdx),
                        timestamp = c.getLong(tsIdx)
                    )
                )
            }
        }
        return list
    }

    fun gameRecordDao(): GameRecordDao = this

    companion object {
        private const val DATABASE_NAME = "labyrinth_database.db"
        private const val DATABASE_VERSION = 1

        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = AppDatabase(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }
}
